$(document).ready(function () {
    isValid = $("#form").validate({
        rules: {
            firstname: {required:true},
            lastname: { required:true},
            u_email:{email:true}
        },
        messages:{
            firstname:{required:"First name can not be empty"},
            lastname: { required:"Last name can not be empty"},
            u_email: {email:"Provide valid email id"}
        }
    });

    if(isValid){
        console.log(document.querySelector("#form").firstname.value)
    }
});

